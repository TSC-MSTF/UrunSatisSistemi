﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UrunSatisSistemi
{
    public partial class Client : Form
    {

        string connString;
        string commandText;
        SqlConnection conn;
        SqlCommand command;

        public Client()
        {
            InitializeComponent();
        }

        private void Client_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Client_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'veritabaniDBDataSet4.URUNLER' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.uRUNLERTableAdapter.Fill(this.veritabaniDBDataSet4.URUNLER);

        }

        private void btnSatinAl_Click(object sender, EventArgs e)
        {
            string urunAdi, Fiyat, StokMiktari;

            urunAdi = dataUrunler.CurrentRow.Cells[0].Value.ToString();
            Fiyat = dataUrunler.CurrentRow.Cells[1].Value.ToString();
            StokMiktari = dataUrunler.CurrentRow.Cells[2].Value.ToString();
            MessageBox.Show(urunAdi + Fiyat + StokMiktari);
            DateTime dateTime = DateTime.Now;

            connString = "Data Source= TSC; " +
                    "Integrated Security= True; Initial Catalog= veriTabaniDB";

            conn = new SqlConnection(connString);

            commandText = String.Format("EXEC INSERTSIPARISLER '{0}', {1}, {2}, {3}",
                urunAdi, Fiyat, dateTime.Date, StokMiktari);


            try
            {
                conn.Open();
                command = new SqlCommand(commandText, conn);
                command.ExecuteNonQuery();
                command.CommandText = "INSERT INTO ADRES VALUES(@NAME,@ACIKLAMA,@KULLANICI_ADI_ID)";
                conn.Close();
                MessageBox.Show("Kayıt Başarıyla Tamamlandı.", "Kayıt Başarılı.", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                
                

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }





        }
    }
}
