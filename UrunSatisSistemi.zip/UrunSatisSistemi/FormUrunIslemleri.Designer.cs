﻿namespace UrunSatisSistemi
{
    partial class FormUrunIslemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textUrunAdi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numerikStokAdedi = new System.Windows.Forms.NumericUpDown();
            this.comboKategori = new System.Windows.Forms.ComboBox();
            this.btnUrunEkle = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.numericUrunFiyati = new System.Windows.Forms.NumericUpDown();
            this.dataUsers = new System.Windows.Forms.DataGridView();
            this.dataUrunler = new System.Windows.Forms.DataGridView();
            this.dataSiparisler = new System.Windows.Forms.DataGridView();
            this.veritabaniDBDataSet = new UrunSatisSistemi.veritabaniDBDataSet();
            this.kULLANICIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kULLANICITableAdapter = new UrunSatisSistemi.veritabaniDBDataSetTableAdapters.KULLANICITableAdapter();
            this.kULLANICIADIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sOYADDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.veritabaniDBDataSet1 = new UrunSatisSistemi.veritabaniDBDataSet1();
            this.uRUNLERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uRUNLERTableAdapter = new UrunSatisSistemi.veritabaniDBDataSet1TableAdapters.URUNLERTableAdapter();
            this.fIYATDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oZELLIKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTOKMIKTARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.veritabaniDBDataSet2 = new UrunSatisSistemi.veritabaniDBDataSet2();
            this.sIPARISLERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sIPARISLERTableAdapter = new UrunSatisSistemi.veritabaniDBDataSet2TableAdapters.SIPARISLERTableAdapter();
            this.dURUMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tARIHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDRESSIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.veritabaniDBDataSet3 = new UrunSatisSistemi.veritabaniDBDataSet3();
            this.gORUNUMLERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gORUNUMLERTableAdapter = new UrunSatisSistemi.veritabaniDBDataSet3TableAdapters.GORUNUMLERTableAdapter();
            this.kULLANICINUMARASIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sOYADIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fULNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mAİLDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDRESBAŞLIĞIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aDRESDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tCKİMLİKNUMARASIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sERİKİMLİKNUMARASIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOĞUMYERİDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uYRUKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eVTELEFONUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cEPTELEFONUDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fAXNUMARASIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.numerikStokAdedi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUrunFiyati)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataUrunler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSiparisler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kULLANICIBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uRUNLERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIPARISLERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gORUNUMLERBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ürün Adı:";
            // 
            // textUrunAdi
            // 
            this.textUrunAdi.Location = new System.Drawing.Point(131, 14);
            this.textUrunAdi.Name = "textUrunAdi";
            this.textUrunAdi.Size = new System.Drawing.Size(176, 20);
            this.textUrunAdi.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ürün Fiyatı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(12, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Stok Adedi:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(12, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Kategori";
            // 
            // numerikStokAdedi
            // 
            this.numerikStokAdedi.Location = new System.Drawing.Point(131, 116);
            this.numerikStokAdedi.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numerikStokAdedi.Name = "numerikStokAdedi";
            this.numerikStokAdedi.Size = new System.Drawing.Size(176, 20);
            this.numerikStokAdedi.TabIndex = 2;
            // 
            // comboKategori
            // 
            this.comboKategori.FormattingEnabled = true;
            this.comboKategori.Location = new System.Drawing.Point(131, 159);
            this.comboKategori.Name = "comboKategori";
            this.comboKategori.Size = new System.Drawing.Size(176, 21);
            this.comboKategori.TabIndex = 3;
            this.comboKategori.Text = "Kategori Seçiniz";
            // 
            // btnUrunEkle
            // 
            this.btnUrunEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUrunEkle.Location = new System.Drawing.Point(16, 219);
            this.btnUrunEkle.Name = "btnUrunEkle";
            this.btnUrunEkle.Size = new System.Drawing.Size(291, 71);
            this.btnUrunEkle.TabIndex = 4;
            this.btnUrunEkle.Text = "Ürün Ekle";
            this.btnUrunEkle.UseVisualStyleBackColor = true;
            this.btnUrunEkle.Click += new System.EventHandler(this.btnUrunEkle_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // numericUrunFiyati
            // 
            this.numericUrunFiyati.Location = new System.Drawing.Point(131, 66);
            this.numericUrunFiyati.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUrunFiyati.Name = "numericUrunFiyati";
            this.numericUrunFiyati.Size = new System.Drawing.Size(176, 20);
            this.numericUrunFiyati.TabIndex = 2;
            // 
            // dataUsers
            // 
            this.dataUsers.AutoGenerateColumns = false;
            this.dataUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kULLANICIADIDataGridViewTextBoxColumn,
            this.aDDataGridViewTextBoxColumn,
            this.sOYADDataGridViewTextBoxColumn});
            this.dataUsers.DataSource = this.kULLANICIBindingSource;
            this.dataUsers.Location = new System.Drawing.Point(314, 12);
            this.dataUsers.Name = "dataUsers";
            this.dataUsers.Size = new System.Drawing.Size(330, 278);
            this.dataUsers.TabIndex = 5;
            // 
            // dataUrunler
            // 
            this.dataUrunler.AutoGenerateColumns = false;
            this.dataUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataUrunler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fIYATDataGridViewTextBoxColumn,
            this.oZELLIKDataGridViewTextBoxColumn,
            this.sTOKMIKTARDataGridViewTextBoxColumn});
            this.dataUrunler.DataSource = this.uRUNLERBindingSource;
            this.dataUrunler.Location = new System.Drawing.Point(650, 12);
            this.dataUrunler.Name = "dataUrunler";
            this.dataUrunler.Size = new System.Drawing.Size(317, 278);
            this.dataUrunler.TabIndex = 5;
            // 
            // dataSiparisler
            // 
            this.dataSiparisler.AutoGenerateColumns = false;
            this.dataSiparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSiparisler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dURUMDataGridViewTextBoxColumn,
            this.tARIHDataGridViewTextBoxColumn,
            this.aDRESSIDDataGridViewTextBoxColumn});
            this.dataSiparisler.DataSource = this.sIPARISLERBindingSource;
            this.dataSiparisler.Location = new System.Drawing.Point(973, 12);
            this.dataSiparisler.Name = "dataSiparisler";
            this.dataSiparisler.Size = new System.Drawing.Size(343, 278);
            this.dataSiparisler.TabIndex = 5;
            // 
            // veritabaniDBDataSet
            // 
            this.veritabaniDBDataSet.DataSetName = "veritabaniDBDataSet";
            this.veritabaniDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // kULLANICIBindingSource
            // 
            this.kULLANICIBindingSource.DataMember = "KULLANICI";
            this.kULLANICIBindingSource.DataSource = this.veritabaniDBDataSet;
            // 
            // kULLANICITableAdapter
            // 
            this.kULLANICITableAdapter.ClearBeforeFill = true;
            // 
            // kULLANICIADIDataGridViewTextBoxColumn
            // 
            this.kULLANICIADIDataGridViewTextBoxColumn.DataPropertyName = "KULLANICI_ADI";
            this.kULLANICIADIDataGridViewTextBoxColumn.HeaderText = "KULLANICI_ADI";
            this.kULLANICIADIDataGridViewTextBoxColumn.Name = "kULLANICIADIDataGridViewTextBoxColumn";
            this.kULLANICIADIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aDDataGridViewTextBoxColumn
            // 
            this.aDDataGridViewTextBoxColumn.DataPropertyName = "AD";
            this.aDDataGridViewTextBoxColumn.HeaderText = "AD";
            this.aDDataGridViewTextBoxColumn.Name = "aDDataGridViewTextBoxColumn";
            // 
            // sOYADDataGridViewTextBoxColumn
            // 
            this.sOYADDataGridViewTextBoxColumn.DataPropertyName = "SOYAD";
            this.sOYADDataGridViewTextBoxColumn.HeaderText = "SOYAD";
            this.sOYADDataGridViewTextBoxColumn.Name = "sOYADDataGridViewTextBoxColumn";
            // 
            // veritabaniDBDataSet1
            // 
            this.veritabaniDBDataSet1.DataSetName = "veritabaniDBDataSet1";
            this.veritabaniDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uRUNLERBindingSource
            // 
            this.uRUNLERBindingSource.DataMember = "URUNLER";
            this.uRUNLERBindingSource.DataSource = this.veritabaniDBDataSet1;
            // 
            // uRUNLERTableAdapter
            // 
            this.uRUNLERTableAdapter.ClearBeforeFill = true;
            // 
            // fIYATDataGridViewTextBoxColumn
            // 
            this.fIYATDataGridViewTextBoxColumn.DataPropertyName = "FIYAT";
            this.fIYATDataGridViewTextBoxColumn.HeaderText = "FIYAT";
            this.fIYATDataGridViewTextBoxColumn.Name = "fIYATDataGridViewTextBoxColumn";
            // 
            // oZELLIKDataGridViewTextBoxColumn
            // 
            this.oZELLIKDataGridViewTextBoxColumn.DataPropertyName = "OZELLIK";
            this.oZELLIKDataGridViewTextBoxColumn.HeaderText = "OZELLIK";
            this.oZELLIKDataGridViewTextBoxColumn.Name = "oZELLIKDataGridViewTextBoxColumn";
            // 
            // sTOKMIKTARDataGridViewTextBoxColumn
            // 
            this.sTOKMIKTARDataGridViewTextBoxColumn.DataPropertyName = "STOK_MIKTAR";
            this.sTOKMIKTARDataGridViewTextBoxColumn.HeaderText = "STOK_MIKTAR";
            this.sTOKMIKTARDataGridViewTextBoxColumn.Name = "sTOKMIKTARDataGridViewTextBoxColumn";
            // 
            // veritabaniDBDataSet2
            // 
            this.veritabaniDBDataSet2.DataSetName = "veritabaniDBDataSet2";
            this.veritabaniDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sIPARISLERBindingSource
            // 
            this.sIPARISLERBindingSource.DataMember = "SIPARISLER";
            this.sIPARISLERBindingSource.DataSource = this.veritabaniDBDataSet2;
            // 
            // sIPARISLERTableAdapter
            // 
            this.sIPARISLERTableAdapter.ClearBeforeFill = true;
            // 
            // dURUMDataGridViewTextBoxColumn
            // 
            this.dURUMDataGridViewTextBoxColumn.DataPropertyName = "DURUM";
            this.dURUMDataGridViewTextBoxColumn.HeaderText = "DURUM";
            this.dURUMDataGridViewTextBoxColumn.Name = "dURUMDataGridViewTextBoxColumn";
            // 
            // tARIHDataGridViewTextBoxColumn
            // 
            this.tARIHDataGridViewTextBoxColumn.DataPropertyName = "TARIH";
            this.tARIHDataGridViewTextBoxColumn.HeaderText = "TARIH";
            this.tARIHDataGridViewTextBoxColumn.Name = "tARIHDataGridViewTextBoxColumn";
            // 
            // aDRESSIDDataGridViewTextBoxColumn
            // 
            this.aDRESSIDDataGridViewTextBoxColumn.DataPropertyName = "ADRESS_ID";
            this.aDRESSIDDataGridViewTextBoxColumn.HeaderText = "ADRESS_ID";
            this.aDRESSIDDataGridViewTextBoxColumn.Name = "aDRESSIDDataGridViewTextBoxColumn";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kULLANICINUMARASIDataGridViewTextBoxColumn,
            this.aDIDataGridViewTextBoxColumn,
            this.sOYADIDataGridViewTextBoxColumn,
            this.fULNAMEDataGridViewTextBoxColumn,
            this.mAİLDataGridViewTextBoxColumn,
            this.aDRESBAŞLIĞIDataGridViewTextBoxColumn,
            this.aDRESDataGridViewTextBoxColumn,
            this.tCKİMLİKNUMARASIDataGridViewTextBoxColumn,
            this.sERİKİMLİKNUMARASIDataGridViewTextBoxColumn,
            this.dOĞUMYERİDataGridViewTextBoxColumn,
            this.uYRUKDataGridViewTextBoxColumn,
            this.eVTELEFONUDataGridViewTextBoxColumn,
            this.cEPTELEFONUDataGridViewTextBoxColumn,
            this.fAXNUMARASIDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.gORUNUMLERBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(314, 306);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(992, 278);
            this.dataGridView1.TabIndex = 6;
            // 
            // veritabaniDBDataSet3
            // 
            this.veritabaniDBDataSet3.DataSetName = "veritabaniDBDataSet3";
            this.veritabaniDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gORUNUMLERBindingSource
            // 
            this.gORUNUMLERBindingSource.DataMember = "GORUNUMLER";
            this.gORUNUMLERBindingSource.DataSource = this.veritabaniDBDataSet3;
            // 
            // gORUNUMLERTableAdapter
            // 
            this.gORUNUMLERTableAdapter.ClearBeforeFill = true;
            // 
            // kULLANICINUMARASIDataGridViewTextBoxColumn
            // 
            this.kULLANICINUMARASIDataGridViewTextBoxColumn.DataPropertyName = "KULLANICI NUMARASI";
            this.kULLANICINUMARASIDataGridViewTextBoxColumn.HeaderText = "KULLANICI NUMARASI";
            this.kULLANICINUMARASIDataGridViewTextBoxColumn.Name = "kULLANICINUMARASIDataGridViewTextBoxColumn";
            // 
            // aDIDataGridViewTextBoxColumn
            // 
            this.aDIDataGridViewTextBoxColumn.DataPropertyName = "ADI";
            this.aDIDataGridViewTextBoxColumn.HeaderText = "ADI";
            this.aDIDataGridViewTextBoxColumn.Name = "aDIDataGridViewTextBoxColumn";
            // 
            // sOYADIDataGridViewTextBoxColumn
            // 
            this.sOYADIDataGridViewTextBoxColumn.DataPropertyName = "SOYADI";
            this.sOYADIDataGridViewTextBoxColumn.HeaderText = "SOYADI";
            this.sOYADIDataGridViewTextBoxColumn.Name = "sOYADIDataGridViewTextBoxColumn";
            // 
            // fULNAMEDataGridViewTextBoxColumn
            // 
            this.fULNAMEDataGridViewTextBoxColumn.DataPropertyName = "FULNAME";
            this.fULNAMEDataGridViewTextBoxColumn.HeaderText = "FULNAME";
            this.fULNAMEDataGridViewTextBoxColumn.Name = "fULNAMEDataGridViewTextBoxColumn";
            this.fULNAMEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // mAİLDataGridViewTextBoxColumn
            // 
            this.mAİLDataGridViewTextBoxColumn.DataPropertyName = "MAİL";
            this.mAİLDataGridViewTextBoxColumn.HeaderText = "MAİL";
            this.mAİLDataGridViewTextBoxColumn.Name = "mAİLDataGridViewTextBoxColumn";
            // 
            // aDRESBAŞLIĞIDataGridViewTextBoxColumn
            // 
            this.aDRESBAŞLIĞIDataGridViewTextBoxColumn.DataPropertyName = "ADRES BAŞLIĞI";
            this.aDRESBAŞLIĞIDataGridViewTextBoxColumn.HeaderText = "ADRES BAŞLIĞI";
            this.aDRESBAŞLIĞIDataGridViewTextBoxColumn.Name = "aDRESBAŞLIĞIDataGridViewTextBoxColumn";
            // 
            // aDRESDataGridViewTextBoxColumn
            // 
            this.aDRESDataGridViewTextBoxColumn.DataPropertyName = "ADRES";
            this.aDRESDataGridViewTextBoxColumn.HeaderText = "ADRES";
            this.aDRESDataGridViewTextBoxColumn.Name = "aDRESDataGridViewTextBoxColumn";
            // 
            // tCKİMLİKNUMARASIDataGridViewTextBoxColumn
            // 
            this.tCKİMLİKNUMARASIDataGridViewTextBoxColumn.DataPropertyName = "TC KİMLİK NUMARASI ";
            this.tCKİMLİKNUMARASIDataGridViewTextBoxColumn.HeaderText = "TC KİMLİK NUMARASI ";
            this.tCKİMLİKNUMARASIDataGridViewTextBoxColumn.Name = "tCKİMLİKNUMARASIDataGridViewTextBoxColumn";
            // 
            // sERİKİMLİKNUMARASIDataGridViewTextBoxColumn
            // 
            this.sERİKİMLİKNUMARASIDataGridViewTextBoxColumn.DataPropertyName = "SERİ KİMLİK NUMARASI";
            this.sERİKİMLİKNUMARASIDataGridViewTextBoxColumn.HeaderText = "SERİ KİMLİK NUMARASI";
            this.sERİKİMLİKNUMARASIDataGridViewTextBoxColumn.Name = "sERİKİMLİKNUMARASIDataGridViewTextBoxColumn";
            // 
            // dOĞUMYERİDataGridViewTextBoxColumn
            // 
            this.dOĞUMYERİDataGridViewTextBoxColumn.DataPropertyName = "DOĞUM YERİ";
            this.dOĞUMYERİDataGridViewTextBoxColumn.HeaderText = "DOĞUM YERİ";
            this.dOĞUMYERİDataGridViewTextBoxColumn.Name = "dOĞUMYERİDataGridViewTextBoxColumn";
            // 
            // uYRUKDataGridViewTextBoxColumn
            // 
            this.uYRUKDataGridViewTextBoxColumn.DataPropertyName = "UYRUK";
            this.uYRUKDataGridViewTextBoxColumn.HeaderText = "UYRUK";
            this.uYRUKDataGridViewTextBoxColumn.Name = "uYRUKDataGridViewTextBoxColumn";
            // 
            // eVTELEFONUDataGridViewTextBoxColumn
            // 
            this.eVTELEFONUDataGridViewTextBoxColumn.DataPropertyName = "EV TELEFONU";
            this.eVTELEFONUDataGridViewTextBoxColumn.HeaderText = "EV TELEFONU";
            this.eVTELEFONUDataGridViewTextBoxColumn.Name = "eVTELEFONUDataGridViewTextBoxColumn";
            // 
            // cEPTELEFONUDataGridViewTextBoxColumn
            // 
            this.cEPTELEFONUDataGridViewTextBoxColumn.DataPropertyName = "CEP TELEFONU";
            this.cEPTELEFONUDataGridViewTextBoxColumn.HeaderText = "CEP TELEFONU";
            this.cEPTELEFONUDataGridViewTextBoxColumn.Name = "cEPTELEFONUDataGridViewTextBoxColumn";
            // 
            // fAXNUMARASIDataGridViewTextBoxColumn
            // 
            this.fAXNUMARASIDataGridViewTextBoxColumn.DataPropertyName = "FAX NUMARASI";
            this.fAXNUMARASIDataGridViewTextBoxColumn.HeaderText = "FAX NUMARASI";
            this.fAXNUMARASIDataGridViewTextBoxColumn.Name = "fAXNUMARASIDataGridViewTextBoxColumn";
            // 
            // FormUrunIslemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1318, 630);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dataSiparisler);
            this.Controls.Add(this.dataUrunler);
            this.Controls.Add(this.dataUsers);
            this.Controls.Add(this.btnUrunEkle);
            this.Controls.Add(this.comboKategori);
            this.Controls.Add(this.numericUrunFiyati);
            this.Controls.Add(this.numerikStokAdedi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textUrunAdi);
            this.Name = "FormUrunIslemleri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormUrunIslemleri";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormUrunIslemleri_FormClosed);
            this.Load += new System.EventHandler(this.FormUrunIslemleri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numerikStokAdedi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUrunFiyati)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataUrunler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSiparisler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kULLANICIBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uRUNLERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sIPARISLERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gORUNUMLERBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textUrunAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numerikStokAdedi;
        private System.Windows.Forms.ComboBox comboKategori;
        private System.Windows.Forms.Button btnUrunEkle;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.NumericUpDown numericUrunFiyati;
        private System.Windows.Forms.DataGridView dataUsers;
        private System.Windows.Forms.DataGridView dataSiparisler;
        private System.Windows.Forms.DataGridView dataUrunler;
        private veritabaniDBDataSet veritabaniDBDataSet;
        private System.Windows.Forms.BindingSource kULLANICIBindingSource;
        private veritabaniDBDataSetTableAdapters.KULLANICITableAdapter kULLANICITableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kULLANICIADIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sOYADDataGridViewTextBoxColumn;
        private veritabaniDBDataSet1 veritabaniDBDataSet1;
        private System.Windows.Forms.BindingSource uRUNLERBindingSource;
        private veritabaniDBDataSet1TableAdapters.URUNLERTableAdapter uRUNLERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIYATDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oZELLIKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTOKMIKTARDataGridViewTextBoxColumn;
        private veritabaniDBDataSet2 veritabaniDBDataSet2;
        private System.Windows.Forms.BindingSource sIPARISLERBindingSource;
        private veritabaniDBDataSet2TableAdapters.SIPARISLERTableAdapter sIPARISLERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dURUMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tARIHDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDRESSIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private veritabaniDBDataSet3 veritabaniDBDataSet3;
        private System.Windows.Forms.BindingSource gORUNUMLERBindingSource;
        private veritabaniDBDataSet3TableAdapters.GORUNUMLERTableAdapter gORUNUMLERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kULLANICINUMARASIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sOYADIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fULNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mAİLDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDRESBAŞLIĞIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDRESDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tCKİMLİKNUMARASIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sERİKİMLİKNUMARASIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOĞUMYERİDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uYRUKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eVTELEFONUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cEPTELEFONUDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fAXNUMARASIDataGridViewTextBoxColumn;
    }
}