﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UrunSatisSistemi
{
    public partial class InsertUser : Form
    {
        
        string connString;
        string commandText;
        SqlConnection conn;
        SqlCommand command;
        Form1 form1 = new Form1();

        public InsertUser()
        {
            InitializeComponent();
        }


        private bool setNullError(TextBox textBox)
        {
            if(textBox.Text == "")
            {
                errorProvider.SetError(textBox, "Boş Geçilemez!");
                return false;
            }

            return true;      
        }

        private bool setNullError(RichTextBox textBox)
        {
            if (textBox.Text == "")
            {
                errorProvider.SetError(textBox, "Boş Geçilemez!");
                return false;
            }

            return true;
        }


        private void btnRegister_Click(object sender, EventArgs e)
        {
            

            if (setNullError(textName) && setNullError(textSurname)
                && setNullError(textPass) && setNullError(textRePass)
                && setNullError(textMail) && setNullError(textAdres))
            {
                connString = "Data Source= TSC; " +
                    "Integrated Security= True; Initial Catalog= veriTabaniDB";

                conn = new SqlConnection(connString);

                commandText = String.Format("EXEC INSERTKULLANICI '{0}', '{1}', {2}, '{3}'",
                    textName.Text, textSurname.Text, textPass.Text, textMail.Text);
                

                try
                {
                    conn.Open();
                    command = new SqlCommand(commandText, conn);
                    command.ExecuteNonQuery();
                    command.CommandText = "INSERT INTO ADRES VALUES(@NAME,@ACIKLAMA,@KULLANICI_ADI_ID)";
                    conn.Close();
                    MessageBox.Show("Kayıt Başarıyla Tamamlandı.", "Kayıt Başarılı.", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    
                    this.Hide();
                    form1.Show();

                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                }



                
            }
            


            
            



            
            
            
        }

        private void InsertUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            form1.Show();
        }
    }
}
