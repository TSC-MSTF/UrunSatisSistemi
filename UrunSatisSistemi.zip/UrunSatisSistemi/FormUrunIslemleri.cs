﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace UrunSatisSistemi
{
    public partial class FormUrunIslemleri : Form
    {
        string connString;
        string commandText;
        SqlConnection conn;
        SqlCommand command;
        SqlDataReader reader;

        public FormUrunIslemleri()
        {
            InitializeComponent();

            connString = "Data Source= TSC; " +
                    "Integrated Security= True; Initial Catalog= veriTabaniDB";
            conn = new SqlConnection(connString);

            commandText = "SELECT * FROM KATEGORILER";
            command = new SqlCommand(commandText, conn);

            try
            {
                conn.Open();
                reader = command.ExecuteReader();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

            while(reader.Read())
            {
                comboKategori.Items.Add(reader.GetString(1));
            }

            conn.Close();

        }
        private bool setNullError(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                errorProvider.SetError(textBox, "Boş Geçilemez!");
                return false;
            }

            return true;
        }

        private bool setComboText(ComboBox comboBox)
        {
            if(comboBox.SelectedIndex == -1)
            {
                errorProvider.SetError(comboBox, "Kategori Seçiniz!");
                return false;
            }

            return true;
        }

        private void FormUrunIslemleri_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnUrunEkle_Click(object sender, EventArgs e)
        {

            if(setNullError(textUrunAdi) && setComboText(comboKategori))
            {
                connString = "Data Source= TSC; " +
                    "Integrated Security= True; Initial Catalog= veriTabaniDB";
                conn = new SqlConnection(connString);

                commandText = String.Format("EXEC INSERTURUN {0}, '{1}', {2}, {3}", numericUrunFiyati.Value,
                    textUrunAdi.Text, numerikStokAdedi.Value, comboKategori.SelectedIndex + 1);
                

                try
                {
                    conn.Open();
                    command = new SqlCommand(commandText, conn);
                    command.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Kayıt Başarıyla Tamamlandı.", "Kayıt Başarılı.", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }


            }

            dataUsers.Update();
            dataUrunler.Update();
            dataSiparisler.Update();
        }

        private void FormUrunIslemleri_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'veritabaniDBDataSet3.GORUNUMLER' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.gORUNUMLERTableAdapter.Fill(this.veritabaniDBDataSet3.GORUNUMLER);
            // TODO: Bu kod satırı 'veritabaniDBDataSet2.SIPARISLER' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.sIPARISLERTableAdapter.Fill(this.veritabaniDBDataSet2.SIPARISLER);
            // TODO: Bu kod satırı 'veritabaniDBDataSet1.URUNLER' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.uRUNLERTableAdapter.Fill(this.veritabaniDBDataSet1.URUNLER);
            // TODO: Bu kod satırı 'veritabaniDBDataSet.KULLANICI' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.kULLANICITableAdapter.Fill(this.veritabaniDBDataSet.KULLANICI);

        }
    }
}
