﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace UrunSatisSistemi
{
    public partial class Form1 : Form
    {
        string connString;
        SqlConnection conn;
        SqlCommand command;
        SqlDataReader reader;

        public Form1()
        {
            
            Thread t = new Thread(new ThreadStart(StartForm));
            t.Start();
            Thread.Sleep(1000);
            t.Abort();
            
            InitializeComponent();
            

            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            connString = "Data Source= TSC; " +
               "Integrated Security= True; Initial Catalog= veriTabaniDB";
            conn = new SqlConnection(connString);

            if (textUser.Text != "admin")
            {
                command = new SqlCommand("SELECT * FROM KULLANICI", conn);
                Boolean login = false;

                try
                {
                    conn.Open();
                    reader = command.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                while (reader.Read())
                {
                    Boolean user = textUser.Text == Convert.ToString(reader.GetValue(0));
                    Boolean pass = textPassword.Text == Convert.ToString(reader.GetValue(3));

                    if (user && pass)
                    {
                        login = true;
                        break;
                    }

                }
                conn.Close();
                if (login)
                {

                    Client client = new Client();
                    this.Hide();
                    client.Show();
                }
                else
                {
                    MessageBox.Show("Kullanıcı Adı veya Şifre Hatalı", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                command = new SqlCommand("SELECT * FROM YONETICI", conn);
                Boolean login = false;

                try
                {
                    conn.Open();
                    reader = command.ExecuteReader();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                while (reader.Read())
                {
                    Boolean user = textUser.Text == Convert.ToString(reader.GetValue(0));
                    Boolean pass = textPassword.Text == Convert.ToString(reader.GetValue(1));

                    if (user && pass)
                    {
                        login = true;
                        break;
                    }

                }
                conn.Close();
                if (login)
                {

                    FormUrunIslemleri formUrunIslemleri = new FormUrunIslemleri();
                    this.Hide();
                    formUrunIslemleri.Show();
                }
                else
                {
                    MessageBox.Show("Kullanıcı Adı veya Şifre Hatalı", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }



        }

        private void insertUser_Click(object sender, EventArgs e)
        {
            
            InsertUser insertUser = new InsertUser();
            this.Hide();
            insertUser.Show();
        }


        public void StartForm()
        {
            Application.Run(new SplashScreen());
        }
    }
}
