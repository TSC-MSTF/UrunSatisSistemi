﻿namespace UrunSatisSistemi
{
    partial class InsertUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textName = new System.Windows.Forms.TextBox();
            this.textSurname = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.labelSurname = new System.Windows.Forms.Label();
            this.textPass = new System.Windows.Forms.TextBox();
            this.textRePass = new System.Windows.Forms.TextBox();
            this.textMail = new System.Windows.Forms.TextBox();
            this.labelPass = new System.Windows.Forms.Label();
            this.labelRePass = new System.Windows.Forms.Label();
            this.labelMail = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.labelAdres = new System.Windows.Forms.Label();
            this.textAdres = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(141, 85);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(177, 20);
            this.textName.TabIndex = 0;
            // 
            // textSurname
            // 
            this.textSurname.Location = new System.Drawing.Point(141, 131);
            this.textSurname.Name = "textSurname";
            this.textSurname.Size = new System.Drawing.Size(177, 20);
            this.textSurname.TabIndex = 1;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(51, 92);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(23, 13);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "Ad:";
            // 
            // labelSurname
            // 
            this.labelSurname.AutoSize = true;
            this.labelSurname.Location = new System.Drawing.Point(51, 138);
            this.labelSurname.Name = "labelSurname";
            this.labelSurname.Size = new System.Drawing.Size(40, 13);
            this.labelSurname.TabIndex = 2;
            this.labelSurname.Text = "Soyad:";
            // 
            // textPass
            // 
            this.textPass.Location = new System.Drawing.Point(141, 176);
            this.textPass.Name = "textPass";
            this.textPass.Size = new System.Drawing.Size(177, 20);
            this.textPass.TabIndex = 1;
            // 
            // textRePass
            // 
            this.textRePass.Location = new System.Drawing.Point(141, 221);
            this.textRePass.Name = "textRePass";
            this.textRePass.Size = new System.Drawing.Size(177, 20);
            this.textRePass.TabIndex = 1;
            // 
            // textMail
            // 
            this.textMail.Location = new System.Drawing.Point(141, 260);
            this.textMail.Name = "textMail";
            this.textMail.Size = new System.Drawing.Size(177, 20);
            this.textMail.TabIndex = 1;
            // 
            // labelPass
            // 
            this.labelPass.AutoSize = true;
            this.labelPass.Location = new System.Drawing.Point(51, 183);
            this.labelPass.Name = "labelPass";
            this.labelPass.Size = new System.Drawing.Size(31, 13);
            this.labelPass.TabIndex = 2;
            this.labelPass.Text = "Şifre:";
            // 
            // labelRePass
            // 
            this.labelRePass.AutoSize = true;
            this.labelRePass.Location = new System.Drawing.Point(51, 228);
            this.labelRePass.Name = "labelRePass";
            this.labelRePass.Size = new System.Drawing.Size(73, 13);
            this.labelRePass.TabIndex = 2;
            this.labelRePass.Text = "Şifre Yeniden:";
            // 
            // labelMail
            // 
            this.labelMail.AutoSize = true;
            this.labelMail.Location = new System.Drawing.Point(51, 267);
            this.labelMail.Name = "labelMail";
            this.labelMail.Size = new System.Drawing.Size(29, 13);
            this.labelMail.TabIndex = 2;
            this.labelMail.Text = "Mail:";
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(141, 398);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(177, 23);
            this.btnRegister.TabIndex = 3;
            this.btnRegister.Text = "Kayıt Ol";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // labelAdres
            // 
            this.labelAdres.AutoSize = true;
            this.labelAdres.Location = new System.Drawing.Point(51, 315);
            this.labelAdres.Name = "labelAdres";
            this.labelAdres.Size = new System.Drawing.Size(37, 13);
            this.labelAdres.TabIndex = 2;
            this.labelAdres.Text = "Adres:";
            // 
            // textAdres
            // 
            this.textAdres.Location = new System.Drawing.Point(141, 312);
            this.textAdres.Name = "textAdres";
            this.textAdres.Size = new System.Drawing.Size(177, 63);
            this.textAdres.TabIndex = 4;
            this.textAdres.Text = "";
            // 
            // InsertUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 517);
            this.Controls.Add(this.textAdres);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.labelAdres);
            this.Controls.Add(this.labelMail);
            this.Controls.Add(this.labelRePass);
            this.Controls.Add(this.labelPass);
            this.Controls.Add(this.labelSurname);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.textMail);
            this.Controls.Add(this.textRePass);
            this.Controls.Add(this.textPass);
            this.Controls.Add(this.textSurname);
            this.Controls.Add(this.textName);
            this.Name = "InsertUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InsertUser";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InsertUser_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textSurname;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelSurname;
        private System.Windows.Forms.TextBox textPass;
        private System.Windows.Forms.TextBox textRePass;
        private System.Windows.Forms.TextBox textMail;
        private System.Windows.Forms.Label labelPass;
        private System.Windows.Forms.Label labelRePass;
        private System.Windows.Forms.Label labelMail;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.RichTextBox textAdres;
        private System.Windows.Forms.Label labelAdres;
    }
}