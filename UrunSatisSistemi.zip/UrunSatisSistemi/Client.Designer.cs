﻿namespace UrunSatisSistemi
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataUrunler = new System.Windows.Forms.DataGridView();
            this.veritabaniDBDataSet4 = new UrunSatisSistemi.veritabaniDBDataSet4();
            this.uRUNLERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uRUNLERTableAdapter = new UrunSatisSistemi.veritabaniDBDataSet4TableAdapters.URUNLERTableAdapter();
            this.oZELLIKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fIYATDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTOKMIKTARDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSatinAl = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataUrunler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uRUNLERBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataUrunler
            // 
            this.dataUrunler.AutoGenerateColumns = false;
            this.dataUrunler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataUrunler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.oZELLIKDataGridViewTextBoxColumn,
            this.fIYATDataGridViewTextBoxColumn,
            this.sTOKMIKTARDataGridViewTextBoxColumn});
            this.dataUrunler.DataSource = this.uRUNLERBindingSource;
            this.dataUrunler.Location = new System.Drawing.Point(12, 12);
            this.dataUrunler.Name = "dataUrunler";
            this.dataUrunler.Size = new System.Drawing.Size(342, 463);
            this.dataUrunler.TabIndex = 0;
            // 
            // veritabaniDBDataSet4
            // 
            this.veritabaniDBDataSet4.DataSetName = "veritabaniDBDataSet4";
            this.veritabaniDBDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uRUNLERBindingSource
            // 
            this.uRUNLERBindingSource.DataMember = "URUNLER";
            this.uRUNLERBindingSource.DataSource = this.veritabaniDBDataSet4;
            // 
            // uRUNLERTableAdapter
            // 
            this.uRUNLERTableAdapter.ClearBeforeFill = true;
            // 
            // oZELLIKDataGridViewTextBoxColumn
            // 
            this.oZELLIKDataGridViewTextBoxColumn.DataPropertyName = "OZELLIK";
            this.oZELLIKDataGridViewTextBoxColumn.HeaderText = "ÜRÜN ADI";
            this.oZELLIKDataGridViewTextBoxColumn.Name = "oZELLIKDataGridViewTextBoxColumn";
            // 
            // fIYATDataGridViewTextBoxColumn
            // 
            this.fIYATDataGridViewTextBoxColumn.DataPropertyName = "FIYAT";
            this.fIYATDataGridViewTextBoxColumn.HeaderText = "FİYAT";
            this.fIYATDataGridViewTextBoxColumn.Name = "fIYATDataGridViewTextBoxColumn";
            // 
            // sTOKMIKTARDataGridViewTextBoxColumn
            // 
            this.sTOKMIKTARDataGridViewTextBoxColumn.DataPropertyName = "STOK_MIKTAR";
            this.sTOKMIKTARDataGridViewTextBoxColumn.HeaderText = "STOK MİKTARI";
            this.sTOKMIKTARDataGridViewTextBoxColumn.Name = "sTOKMIKTARDataGridViewTextBoxColumn";
            // 
            // btnSatinAl
            // 
            this.btnSatinAl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSatinAl.Location = new System.Drawing.Point(361, 13);
            this.btnSatinAl.Name = "btnSatinAl";
            this.btnSatinAl.Size = new System.Drawing.Size(314, 136);
            this.btnSatinAl.TabIndex = 1;
            this.btnSatinAl.Text = "Satın Al";
            this.btnSatinAl.UseVisualStyleBackColor = true;
            this.btnSatinAl.Click += new System.EventHandler(this.btnSatinAl_Click);
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1229, 600);
            this.Controls.Add(this.btnSatinAl);
            this.Controls.Add(this.dataUrunler);
            this.Name = "Client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Client";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Client_FormClosed);
            this.Load += new System.EventHandler(this.Client_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataUrunler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.veritabaniDBDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uRUNLERBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataUrunler;
        private veritabaniDBDataSet4 veritabaniDBDataSet4;
        private System.Windows.Forms.BindingSource uRUNLERBindingSource;
        private veritabaniDBDataSet4TableAdapters.URUNLERTableAdapter uRUNLERTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn oZELLIKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIYATDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sTOKMIKTARDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnSatinAl;
    }
}