﻿namespace UrunSatisSistemi
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.textUser = new System.Windows.Forms.TextBox();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.insertUser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textUser
            // 
            this.textUser.Location = new System.Drawing.Point(97, 96);
            this.textUser.Name = "textUser";
            this.textUser.Size = new System.Drawing.Size(166, 20);
            this.textUser.TabIndex = 0;
            this.textUser.Text = "admin";
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(97, 138);
            this.textPassword.Name = "textPassword";
            this.textPassword.Size = new System.Drawing.Size(166, 20);
            this.textPassword.TabIndex = 1;
            this.textPassword.Text = "admin";
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(97, 180);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(166, 23);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Giriş";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // insertUser
            // 
            this.insertUser.AutoSize = true;
            this.insertUser.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.insertUser.Location = new System.Drawing.Point(97, 225);
            this.insertUser.Name = "insertUser";
            this.insertUser.Size = new System.Drawing.Size(82, 13);
            this.insertUser.TabIndex = 3;
            this.insertUser.Text = "Kullanıcı Oluştur";
            this.insertUser.Click += new System.EventHandler(this.insertUser_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 397);
            this.Controls.Add(this.insertUser);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.textPassword);
            this.Controls.Add(this.textUser);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giriş Yap";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textUser;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label insertUser;
    }
}

